double			d_min(struct position pos, int level);
double			distance(struct position pos1,struct position pos2);
double         energy_k(int level);
double			energy_p(int level);
void distances_pairs(int level);
void informative_links (int level);



